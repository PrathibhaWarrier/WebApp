const { REACT_APP_SERVER_API} = process.env;
// export const API_MV="http://ec2-13-235-78-250.ap-south-1.compute.amazonaws.com/mvdb";
 export const API_MV= "http://for.hosting.com:8083/mvdb";
// export const API_MV=REACT_APP_SERVER_API+"/mvdb";