/*!

=========================================================
* Black Dashboard React v1.2.0
=========================================================

* Product Page: https://www.creative-tim.com/product/black-dashboard-react
* Copyright 2020 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/black-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React, { useEffect, useState } from "react";
// nodejs library that concatenates classes
import classNames from "classnames";
import axios from 'axios';
import { API_MV } from '../constants/API';
// react plugin used to create charts
import { Line, Bar } from "react-chartjs-2";

import DecChart from '../variables/DecemberChart'
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
// reactstrap components
import {
  Button,
  ButtonGroup,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
  Label,
  FormGroup,
  Input,
  Table,
  Row,
  Col,
  UncontrolledTooltip,
} from "reactstrap";

// core components
import {
  chartExample1,
  chartExample2,
  chartExample3,
  chartExample4,
} from "variables/charts.js";


function Dashboard(props) {

  const [chartMonth, setChartMonth] = useState(new Date().getMonth());
  const [chartYear, setChartYear] = useState(new Date().getFullYear());
  const [chartCaseType, setChartCaseType] = useState("barcode");



  return (
    <>
      <div className="content">
        <Row>
          <Col xs="12">
            <Card className="card-chart">
              <CardHeader>
                <FormControl>
                  <Select
                    native
                    // value={"Default"}
                    onChange={(e) => { setChartCaseType(e.target.value) }}>
                    <option selected value="barcode">Scan QR/Barcode</option>
                    <option value="dimension">Dimension Check</option>
                    <option value="sorting">Sorting</option>
                    <option value="colour">Colour Concentration</option>
                    <option value="liquidlevel">Liquid Level</option>
                    <option value="sealquality">Seal Quality</option>
                  </Select>
                  </FormControl>
                  
                <FormControl>
                  <Select
                    native
                    // value={"Default"}
                    onChange={(e) => { setChartMonth(e.target.value) }}>
                    <option selected value={0}>January</option>
                    <option value={1}>Febuary</option>
                    <option value={2}>March</option>
                    <option value={3}>April</option>
                    <option value={4}>May</option>
                    <option value={5}>June</option>
                    <option value={6}>July</option>
                    <option value={7}>August</option>
                    <option value={8}>September</option>
                    <option value={9}>October</option>
                    <option value={10}>November</option>
                    <option value={11}>December</option>
                    
                  </Select>
                  </FormControl>
                <FormControl>
                  <Select
                    native
                    // value={"Default"}
                    onChange={(e) => { setChartYear(e.target.value) }}>
                    <option selected value={2020}>2020</option>
                    <option value={2021}>2021</option>
                  </Select>

                </FormControl>
                <Row>
                  <Col className="text-left" sm="6">
                    <h5 className="card-category">Data Inspection</h5>
                    <CardTitle tag="h2">Performance</CardTitle>
                  </Col>
                  <Col sm="6">
                    <ButtonGroup
                      className="btn-group-toggle float-right"
                      data-toggle="buttons"
                    >

                      <span className="d-none d-sm-block d-md-block d-lg-block d-xl-block">
                        Sessions
                        </span>
                      <span className="d-block d-sm-none">
                        <i className="tim-icons icon-tap-02" />
                      </span>
                      {/* </Button> */}
                    </ButtonGroup>
                  </Col>
                </Row>
              </CardHeader>
              <CardBody>
                <div className="chart-area">
                  <DecChart month={chartMonth} year={chartYear} casetype={chartCaseType}/>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>

      </div>
    </>
  );
}

export default Dashboard;
