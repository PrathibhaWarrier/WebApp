/*!

=========================================================
* Black Dashboard React v1.2.0
=========================================================

* Product Page: https://www.creative-tim.com/product/black-dashboard-react
* Copyright 2020 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/black-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import {API_MV} from '../constants/API';
import React, { useState, useEffect } from "react";
import axios from 'axios';
import DateFnsUtils from '@date-io/date-fns';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import './barcodecss.css'

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";

function formatDate(date) {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
      day = '0' + day;

  return [year, month, day].join('-');
}

function Tables() {
//  const initialData=[{date:null,barcode_data:null, counter:null}]
 const [tbdata, setTbdata]=useState([]);
 
 const [fromDate, setFromDate]=useState(new Date());
 const [toDate, setToDate]=useState(new Date());
 const [err, seterr]=useState(0);
 const [isDone, setIsDone]=useState(false);


 
 const handleFromDateChange=(evtdate)=>{
   const fdate=evtdate;
  // fdate=formatDate(fdate);
   setFromDate(fdate);
 }

 const handleToDateChange=(evtdate)=>{
  const tdate=evtdate;
  // tdate=formatDate(tdate);
  setToDate(tdate);
 }

 const handleSubmit=(evt)=>
 {evt.preventDefault();
   if(fromDate<=toDate)
   {
    let start=formatDate(fromDate);
    let end=formatDate(toDate);
    console.log(start);
    console.log(end);
    axios.get(`${API_MV}/dimension/${start}/${end}`)
    .then((response)=>{setTbdata(response.data);setIsDone(true);console.log(response)})
    .catch(error=>{seterr(error);console.log(error)})
   }
  
 }

 const showData=()=>
 {
 const reqData=tbdata.map(row=>{
    return(
      <tr>
        <td>{row.date}</td>
        <td>{row.object}</td>
        <td>{row.dimension_1}</td>
        <td>{row.dimension_2}</td>
      </tr> 
    )});
    return reqData;

 }

  return (
    <React.Fragment> 
    
      <div className="content">
        
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Object Dimenssion</CardTitle>
              </CardHeader>
              <CardBody>

                
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <Grid container justify="space-around">
        <form onSubmit={handleSubmit}>
        <KeyboardDatePicker
          // disableToolbar
          variant="inline"
          format="dd/MM/yyyy"
          margin="normal"
          id="start-date"
          label="Start Date"
          value={fromDate}
          onChange={handleFromDateChange}
          KeyboardButtonProps={{
            'aria-label': 'selected',
          }}
        />
        <KeyboardDatePicker
          variant="inline" 
          margin="normal"
          id="end-date"
          label="End Date "
          format="dd/MM/yyyy"
          value={toDate}
          onChange={handleToDateChange}
          KeyboardButtonProps={{
            'aria-label': 'selected',
          }}
        />
      
      <Button
        variant="contained"
        type="submit"
        color="primary"
        
      >
        Submit
      </Button>
      </form>
       
      </Grid>

    </MuiPickersUtilsProvider>
                
                <Table className="tablesorter" responsive>
                  <thead className="text-primary">
                    <tr>
                      {/* <th>Numbe</th> */}
                      <th className="text-center">Date</th>
                      <th className="text-center">Object</th>
                      <th className="text-center">Dimension 1</th>
                      <th className="text-center">Dimension 2</th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    {console.log(isDone)}
                    {isDone?showData():null}
                   
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
          
        </Row>
      </div>
      </React.Fragment>
  );
}

export default Tables;
