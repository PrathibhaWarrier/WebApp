/*!

=========================================================
* Black Dashboard React v1.2.0
=========================================================

* Product Page: https://www.creative-tim.com/product/black-dashboard-react
* Copyright 2020 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/black-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React, { useState, useEffect } from "react";
import axios from 'axios';
import DateFnsUtils from '@date-io/date-fns';
import Grid from '@material-ui/core/Grid';
import Icon from '@material-ui/core/Icon';
import Button from '@material-ui/core/Button';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import './barcodecss.css'

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";

function formatDate(date) {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
      day = '0' + day;

  return [year, month, day].join('-');
}

function Tables() {
//  const initialData=[{date:null,barcode_data:null, counter:null}]
 const [tbdata, setTbdata]=useState([]);
 
 const [fromDate, setFromDate]=useState(new Date());
 const [toDate, setToDate]=useState(new Date());
 const [err, seterr]=useState(0);
 const [isDone, setIsDone]=useState(false);

//  useEffect(()=>{
//    return console.log("HI")
//  },[])
 
 const handleFromDateChange=(evtdate)=>{
   const fdate=evtdate;
  // fdate=formatDate(fdate);
   setFromDate(fdate);
 }

 const handleToDateChange=(evtdate)=>{
  const tdate=evtdate;
  // tdate=formatDate(tdate);
  setToDate(tdate);
 }

 const handleSubmit=(evt)=>
 {evt.preventDefault();
   if(fromDate<=toDate)
   {
    let start=formatDate(fromDate);
    let end=formatDate(toDate);
    console.log(start);
    console.log(end);
    axios.get(`http://127.0.0.1:8000/api/Capacity/`)
    .then((response)=>{setTbdata(response.data);setIsDone(true);console.log(response)})
    .catch(error=>{seterr(error);console.log(error)})
   }
  
 }

 const showData=()=>
 {
 const reqData=tbdata.map(row=>{
    return(
      <tr>
        <td>{row.id}</td>
        <td>{row.Plant}</td>
        <td>{row.Phase}</td>
      </tr> 
    )});
    return reqData;

 }

  return (
    <React.Fragment> 
    {/* <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <Grid container justify="space-around">
        <form onSubmit={handleSubmit}>
        <KeyboardDatePicker
          disableToolbar
          variant="inline"
          format="dd/MM/yyyy"
          margin="normal"
          id="start-date"
          label="Start Date"
          // value={selectedDate}
          onChange={handleFromDateChange}
          KeyboardButtonProps={{
            'aria-label': 'selected',
          }}
        />
        <KeyboardDatePicker
          variant="inline" 
          margin="normal"
          id="end-date"
          label="End Date "
          format="dd/MM/yyyy"
          // value={selectedDate}
          onChange={handleToDateChange}
          KeyboardButtonProps={{
            'aria-label': 'selected',
          }}
        />
       
      <Button
        variant="contained"
        type="submit"
        color="primary"
        // className={classes.button}
        endIcon={<Icon>send</Icon>}
      >
        Submit
      </Button>
      </form>
       
      </Grid>



    </MuiPickersUtilsProvider> */}

      <div className="content">
        
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Scan QR/Barcode</CardTitle>
              </CardHeader>
              <CardBody>

                
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <Grid container justify="space-around">
        <form onSubmit={handleSubmit}>
        <KeyboardDatePicker
          // disableToolbar
          variant="inline"
          format="dd/MM/yyyy"
          margin="normal"
          id="start-date"
          label="Start Date"
          value={fromDate}
          onChange={handleFromDateChange}
          KeyboardButtonProps={{
            'aria-label': 'selected',
          }}
        />
        <KeyboardDatePicker
          variant="inline" 
          margin="normal"
          id="end-date"
          label="End Date "
          format="dd/MM/yyyy"
          value={toDate}
          onChange={handleToDateChange}
          KeyboardButtonProps={{
            'aria-label': 'selected',
          }}
        />
      
      <Button
        variant="contained"
        type="submit"
        color="primary"
        // className={classes.button}
        // endIcon={<Icon>send</Icon>}
      >
        Submit
      </Button>
      </form>
       
      </Grid>

    </MuiPickersUtilsProvider>
                
                <Table className="tablesorter" responsive>
                  <thead className="text-primary">
                    <tr>
                        
                      {/* <th>Numbe</th> */}
                      <th className="text-center">Date</th>
                      <th className="text-center">Barcode Data</th>
                      <th className="text-center">Counter</th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    {console.log(isDone)}
                    {isDone?showData():null}
                    {/* <tr>
                      <td>1</td>
                      <td>2020-11-14</td>
                      <td>www.google.com</td>
                      <td className="text-center">2</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>2020-11-14</td>
                      <td>www.yahoo.com</td>
                      <td className="text-center">3</td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>2020-11-15</td>
                      <td>www.Sutherlands.in</td>
                      <td className="text-center">1</td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>2020-11-15</td>
                      <td>wiki.ink</td>
                      <td className="text-center">6</td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>2020-11-16</td>
                      <td>paytm.in</td>
                      <td className="text-center">2</td>
                    </tr>
                    <tr>
                      <td>6</td>
                      <td>2020-11-17</td>
                      <td>chile.in</td>
                      <td className="text-center">5</td>
                    </tr>
                    <tr>
                      <td>7</td>
                      <td>2020-11-17</td>
                      <td>Nike.in</td>
                      <td className="text-center">2</td>
                    </tr> */}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
          {/* <Col md="12">
            <Card className="card-plain">
              <CardHeader>
                <CardTitle tag="h4"> Plain Background</CardTitle>
                <p className="category">Here is a subtitle for this table</p>
              </CardHeader>
              <CardBody>
                <Table className="tablesorter" responsive>
                  <thead className="text-primary">
                    <tr>
                      <th>Name</th>
                      <th>Country</th>
                      <th>City</th>
                      <th className="text-center">Salary</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Dakota Rice</td>
                      <td>Niger</td>
                      <td>Oud-Turnhout</td>
                      <td className="text-center">$36,738</td>
                    </tr>
                    <tr>
                      <td>Minerva Hooper</td>
                      <td>Curaçao</td>
                      <td>Sinaai-Waas</td>
                      <td className="text-center">$23,789</td>
                    </tr>
                    <tr>
                      <td>Sage Rodriguez</td>
                      <td>Netherlands</td>
                      <td>Baileux</td>
                      <td className="text-center">$56,142</td>
                    </tr>
                    <tr>
                      <td>Philip Chaney</td>
                      <td>Korea, South</td>
                      <td>Overland Park</td>
                      <td className="text-center">$38,735</td>
                    </tr>
                    <tr>
                      <td>Doris Greene</td>
                      <td>Malawi</td>
                      <td>Feldkirchen in Kärnten</td>
                      <td className="text-center">$63,542</td>
                    </tr>
                    <tr>
                      <td>Mason Porter</td>
                      <td>Chile</td>
                      <td>Gloucester</td>
                      <td className="text-center">$78,615</td>
                    </tr>
                    <tr>
                      <td>Jon Porter</td>
                      <td>Portugal</td>
                      <td>Gloucester</td>
                      <td className="text-center">$98,615</td>
                    </tr>
                  </tbody>
                </Table>
              </CardBody> */}
            {/* </Card>
          </Col> */}
        </Row>
      </div>
      </React.Fragment>
  );
}

export default Tables;
