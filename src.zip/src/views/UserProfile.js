import React, { useState } from "react";
import './barcodecss.css'; 
// reactstrap components
import {
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
} from "reactstrap";

function Example(props) {
  // const [selPlant, setSelPlant]=useState(null)
  const plantdrop= ()=>{
    let plant=Array.from(props.plant);
    console.log(plant);
    // console.log(selPlant);
    return(plant.map(val =>{
      return(
      <li>
        <DropdownItem href="#pablo" onClick={(e) => {e.preventDefault(); props.filterPlantCallback({val})}}>
        {val}
      </DropdownItem>
      </li>)
    }));
  }
  
  return (
    <div className="MyDropdown">
    <>
      <UncontrolledDropdown>
        <DropdownToggle
          caret
          color="secondary"
          id="dropdownMenuButton"
          type="button"
        >
          Regular
        </DropdownToggle>

        <DropdownMenu aria-labelledby="dropdownMenuButton">
        {plantdrop()}
        </DropdownMenu>
      </UncontrolledDropdown>

      <UncontrolledDropdown>
        <DropdownToggle caret color="default">
          <img
            alt="..."
            src="https://demos.creative-tim.com/argon-dashboard-pro-bs4/assets/img/icons/flags/US.png"
          ></img>
          Flags
        </DropdownToggle>

        <DropdownMenu>
          <li>
            <DropdownItem href="#pablo" onClick={(e) => e.preventDefault()}>
              <img
                alt="..."
                src="https://demos.creative-tim.com/argon-dashboard-pro-bs4/assets/img/icons/flags/DE.png"
              ></img>
              Deutsch
            </DropdownItem>
          </li>

          <li>
            <DropdownItem href="#pablo" onClick={(e) => e.preventDefault()}>
              <img
                alt="..."
                src="https://demos.creative-tim.com/argon-dashboard-pro-bs4/assets/img/icons/flags/GB.png"
              ></img>
              English(UK)
            </DropdownItem>
          </li>

          <li>
            <DropdownItem href="#pablo" onClick={(e) => e.preventDefault()}>
              <img
                alt="..."
                src="https://demos.creative-tim.com/argon-dashboard-pro-bs4/assets/img/icons/flags/FR.png"
              ></img>
              FranÃ§ais
            </DropdownItem>
          </li>
        </DropdownMenu>
      </UncontrolledDropdown>
    </>
    </div>
  );
}

export default Example;

