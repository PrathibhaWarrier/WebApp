/*!

=========================================================
* Black Dashboard React v1.2.0
=========================================================

* Product Page: https://www.creative-tim.com/product/black-dashboard-react
* Copyright 2020 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/black-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import Dashboard from "views/Dashboard.js";
import Barcode from "views/Barcode.js";
import Colourcon from "views/Colourcon.js";
import Dimension from "views/Dimension.js";
import Liquid from "views/Liquid.js";
import Seal from "views/Seal.js";
import Sorting from "views/Sorting.js";
// import UserProfile from "views/UserProfile.js";

var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "tim-icons icon-chart-pie-36",
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/barcode",
    name: "Scan QR/Barcode",
    icon: "tim-icons icon-atom",
    component: Barcode,
    layout: "/admin",
  },
  {
    path: "/liquid",
    name: "Liquid Level",
    icon: "tim-icons icon-pin",
    component: Liquid,
    layout: "/admin",
  },
  {
    path: "/colourcon",
    name: "Colour Concentration",
    icon: "tim-icons icon-bell-55",
    component: Colourcon,
    layout: "/admin",
  },


  // {
  //   path: "/user-profile",
  //   name: "Object Dimension",
  //   rtlName: "ملف تعريفي للمستخدم",
  //   icon: "tim-icons icon-single-02",
  //   component: UserProfile,
  //   layout: "/admin",
  // },
  {
    path: "/dimension",
    name: "Dimension",
    icon: "tim-icons icon-puzzle-10",
    component: Dimension,
    layout: "/admin",
  },
  {
    path: "/sealquality",
    name: "Seal Quality",
    icon: "tim-icons icon-align-center",
    component: Seal,
    layout: "/admin",
  },
  {
    path: "/sorting",
    name: "Sorting",
    icon: "tim-icons icon-align-center",
    component: Sorting,
    layout: "/admin",
  }
  
];
export default routes;
