import React,{useEffect,useState} from "react";
import axios from 'axios';
import {API_MV} from '../constants/API';
import { Line} from "react-chartjs-2";

function formatDate(date) {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
      day = '0' + day;

  return [year, month, day].join('-');
}

export default function DecemberChart(props){
    // const [bigChartData, setbigChartData] = React.useState();
    const [chartdata1, setChartdata1]=useState([100, 70, 90, 70, 85, 60, 75, 60, 90, 80, 110, 100]);
    const [chartdata2, setChartdata2]=useState([]);
    const [chartdata3, setChartdata3]=useState([]);
    const [chartdata4, setChartdata4]=useState([]);
    const [xaxis,setXaxis]=useState([]);
    const [min,setMin]=useState(0);
    const [max,setMax]=useState(20);
    // const barcodeAPI=`${API_MV}/barcode`;
    
    useEffect(() => {
      // console.log(props.month);
      // console.log(new Date().getMonth());
      let xmonth=[];
      for(let i=1;i<=(new Date(props.year,parseInt(props.month)+1,0).getDate());i++)
    { xmonth.push(i);
    }
    console.log(xmonth);
    setXaxis(xmonth);
  },[props.month,props.year]);

    useEffect(() => {
      console.log(props.casetype);
       console.log(`${API_MV}/${props.casetype}/${formatDate(new Date(props.year,props.month))}/${formatDate(new Date(props.year,parseInt(props.month)+1,0))}`);
       axios.get(`${API_MV}/${props.casetype}/${formatDate(new Date(props.year,props.month))}/${formatDate(new Date(props.year,parseInt(props.month)+1,0))}`)
          .then((res)=>{
            console.log(res.data);
            let minval=999;
            let maxval=0;
            // setChartdata1(res.data.map(val=>{
            //   if(minval>val.counter){
            //     minval=val.counter;
            //   }
            //   if(maxval<val.counter){
            //     maxval=val.counter;
            //   }
            //     console.log(val.counter);
            //   return val.counter;
            // }))
            // console.log(minval+":min           max:"+maxval);
            // setMin(minval);
            // setMax(maxval+10);
            let a=[];
            let b=[];
            let c=[];
            let d=[];
            switch(props.casetype){
              case "barcode":{
                for(let i=1;i<new Date(props.year,parseInt(props.month)+1,0).getDate();i++){
                
                  a[i-1]=res.data.reduce((acc,val)=>{
            
                    if(new Date(val.date).getDate()==i){
                     acc=acc+val.counter
                    }
                    
                    return acc
                  },0)
                  if(minval>a[i-1]){
                        minval=a[i-1];
                      }
                      if(maxval<a[i-1]){
                        maxval=a[i-1];
                      }
                }
                break;
              }
              case "liquidlevel":{
                for(let i=1;i<new Date(props.year,parseInt(props.month)+1,0).getDate();i++){
                
                  a[i-1]=res.data.reduce((acc,val)=>{
            
                    if(new Date(val.date).getDate()==i && val.fill_level==="pass" ){
                     acc=acc+1
                    }
                     
                    return acc
                  },0)

                  b[i-1]=res.data.reduce((acc,val)=>{
            
                    if(new Date(val.date).getDate()==i && val.fill_level==="fail" ){
                     acc=acc+1
                    }
                    return acc
                  },0)
                  if(minval>a[i-1]){
                        minval=a[i-1];
                      }
                      if(maxval<a[i-1]){
                        maxval=a[i-1];
                      }

              }
              break;
            }
          }
            
            console.log(a);
            console.log(minval+":min           max:"+maxval);
            setMin(minval);
            setMax(maxval+10);
            setChartdata1(a);
            setChartdata2(b);

          })
          .catch(error=>{
            console.log(error);
          })
          // },[chartdata1]);
        },[props.casetype,props.month,props.year]);
        
    // useEffect(() => {  setbigChartData(chartdata())    },[chartdata1]);
    
    const chartdata = () => {
      // let ctx = canvas.getContext("2d");
  
      // let gradientStroke = ctx.createLinearGradient(0, 230, 0, 50);
  
      // gradientStroke.addColorStop(1, "rgba(29,140,248,0.2)");
      // gradientStroke.addColorStop(0.4, "rgba(29,140,248,0.0)");
      // gradientStroke.addColorStop(0, "rgba(29,140,248,0)"); //blue colors
  
      return {
         labels:xaxis,
        // [
        //   "1",
        //   "2",
        //   "3",
        //   "4",
        //   "5",
        //   "6",
        //   "7",
        //   "8",
        //   "9",
        //   "10",
        //   "11",
        //   "12",
        //   "13",
        //   "14",
        //   "15",
        //   "16",
        //   "17",
        //   "18",
        //   "19",
        //   "20",
        //   "21",
        //   "22",
        //   "23",
        //   "24",
        //   "25",
        //   "26",
        //   "27",
        //   "28",
        //   "29",
        //   "30",
        //   "31",
        // ],
        datasets: [
          {
            label: "My First dataset",
            fill: true,
            // backgroundColor: gradientStroke,
            borderColor: "#1f8ef1",
            borderWidth: 2,
            // borderDash: [2],
            // borderDashOffset: 0.0,
            pointBackgroundColor: "#1f8ef1",
            pointBorderColor: "rgba(255,255,255,0)",
            pointHoverBackgroundColor: "#1f8ef1",
            // pointBorderWidth: 20,
            pointHoverRadius: 5,
            // pointHoverBorderWidth: 15,
            pointRadius: 3,
            data: chartdata1
          },
          {
            label: "My Second dataset",
            fill: true,
            borderColor: "#1f8ef1",
            borderWidth: 2,
            pointBackgroundColor: "#1f8ef1",
            pointBorderColor: "rgba(255,255,255,0)",
            pointHoverBackgroundColor: "#1f8ef1",
            pointHoverRadius: 5,
            pointRadius: 3,
            data: chartdata2
          },
          {
            label: "My Third dataset",
            fill: true,
            borderColor: "#1f8ef1",
            borderWidth: 2,
            pointBackgroundColor: "#1f8ef1",
            pointBorderColor: "rgba(255,255,255,0)",
            pointHoverBackgroundColor: "#1f8ef1",
            pointHoverRadius: 5,
            pointRadius: 3,
            data: chartdata3
          },
          {
            label: "My Fourth dataset",
            fill: true,
            borderColor: "#1f8ef1",
            borderWidth: 2,
            pointBackgroundColor: "#1f8ef1",
            pointBorderColor: "rgba(255,255,255,0)",
            pointHoverBackgroundColor: "#1f8ef1",
            pointHoverRadius: 5,
            pointRadius: 3,
            data: chartdata4
          }
        ],
      };
    }
    let chartoptions = {
      maintainAspectRatio: false,
      legend: {
        display: false,
      },
      tooltips: {
        backgroundColor: "#f5f5f5",
        titleFontColor: "#333",
        bodyFontColor: "#666",
        bodySpacing: 4,
        xPadding: 12,
        mode: "nearest",
        intersect: 0,
        position: "nearest",
      },
      responsive: true,
      scales: {
        yAxes: [
          {
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: "rgba(29,140,248,0.0)",
              zeroLineColor: "transparent",
            },
            ticks: {
              suggestedMin: min,
              suggestedMax: max,
              padding: 20,
              fontColor: "#9a9a9a",
            },
          },
        ],
        xAxes: [
          {
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: "rgba(29,140,248,0.1)",
              zeroLineColor: "transparent",
            },
            ticks: {
              padding: 20,
              fontColor: "#9a9a9a",
            },
          },
        ],
      },
    };
    
    return(
        <Line
                    data={chartdata()}
                    options={chartoptions}
                  />
    );
}