import React, { useReducer, useEffect, useState } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import {useHistory} from 'react-router-dom';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Avatar from '@material-ui/core/Avatar';
import Container from '@material-ui/core/Container';
import CssBaseline from '@material-ui/core/CssBaseline';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import axios from 'axios';
import {API_MV} from '../constants/API';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
    color: 'black'
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));


const initialState = {
  username: '',
  password: '',
  isButtonDisabled: true,
  helperText: '',
  isError: false
};


const reducer = (state, action) => {
  switch (action.type) {
    case 'setUsername': 
      return {
        ...state,
        username: action.payload
      };
    case 'setPassword': 
      return {
        ...state,
        password: action.payload
      };
    case 'setIsButtonDisabled': 
      return {
        ...state,
        isButtonDisabled: action.payload
      };
    case 'loginSuccess': 
      return {
        ...state,
        helperText: action.payload,
        isError: false
      };
    case 'loginFailed': 
      return {
        ...state,
        helperText: action.payload,
        isError: true
      };
    case 'setIsError': 
      return {
        ...state,
        isError: action.payload
      };
  }
}

const Login = () => {
  let history = useHistory();
  const classes = useStyles();
  const [state, dispatch] = useReducer(reducer, initialState);
  const [isDone,setDone]=useState(false);
  useEffect(() => {
    if (state.username.trim() && state.password.trim()) {
     dispatch({
       type: 'setIsButtonDisabled',
       payload: false
     });
    } else {
      dispatch({
        type: 'setIsButtonDisabled',
        payload: true
      });
    }
  }, [state.username, state.password]);

 

  // const afterLogin =() => {
  //   isDone? history.push("/admin"):null
  // } 

  // useEffect(() =>{
  //   afterLogin();
  // },[isDone]);

  // const handleKeyPress = (event) => {
  //   if (event.keyCode === 13 || event.which === 13) {
  //     state.isButtonDisabled || handleSignIn();
  //   }
  // };

  const handleUsernameChange =
    (event) => {
      dispatch({
        type: 'setUsername',
        payload: event.target.value
      });
    };

  const handlePasswordChange =
    (event) => {
      dispatch({
        type: 'setPassword',
        payload:event.target.value
      });
    }
    const handleSignIn = (e) => {
      e.preventDefault();
      setDone(false);
      
      const data={
        userName:state.username,
        password:state.password
      }
      const headers = {
        'Content-Type': 'application/json',
        // 'Authorization': `Bearer ${accessToken}`
      }
      console.log(`${API_MV}/auth/authenticate`);
      axios.defaults.withCredentials = true;
      axios.post(`${API_MV}/auth/authenticate`, data, {headers: headers})
      .then((res)=>{
        console.log(res.status);
        if(res.status===200){
          dispatch({
            type: 'loginSuccess',
            payload: 'Login Successfully'
          });
          
          console.log(res.data);
          setDone(true);
          
        }
        else{
          throw new Error();
        }
      })
      .catch(err=>{
        console.log(err);
        dispatch({
              type: 'loginFailed',
              payload: 'Incorrect username or password'
            });
      })
     
      } 
  return (
    
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      {isDone? history.push("/admin"):null}
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <form className={classes.form} onSubmit={handleSignIn}>
            <TextField
              error={state.isError}
              fullWidth
              id="username"
              type="text"
              label="Username"
              placeholder="Username"
              margin="normal"
              onChange={handleUsernameChange}
              // onKeyPress={handleKeyPress}
            />
            <TextField
              error={state.isError}
              fullWidth
              id="password"
              type="password"
              label="Password"
              placeholder="Password"
              margin="normal"
              helperText={state.helperText}
              onChange={handlePasswordChange}
              // onKeyPress={handleKeyPress}
              
            />
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Remember me"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
          >
            Sign In
          </Button>
          <Grid container>
            <Grid item xs>
              <Link to="#" variant="body2">
                Forgot password?
              </Link>
            </Grid>
         
          </Grid>
        </form>
      </div>
     
    </Container>
  );
}
const Footer = () => (
  <footer className="footer">
    <p>Some footer nonsense!</p>
  </footer>
);
export default Login;