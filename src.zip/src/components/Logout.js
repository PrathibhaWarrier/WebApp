import React,{useState} from 'react';
import axios from 'axios';
import {API_MV} from '../constants/API';
import {useHistory} from 'react-router-dom';

import {
    Button,
    DropdownMenu,
    DropdownItem,
    // NavLink,
  } from "reactstrap";
  import Link from '@material-ui/core/Link';

export default function Logout(){
    let history = useHistory();
    const [isDone,setDone]=useState(false);
    function handleLogout() {
        axios.post(`${API_MV}/auth/logout`)
             .then((res)=>{
                console.log(res.status);
                if(res.status===200){
                    setDone(true);
             } 
            })
            .catch((error)=>{
                console.log(error);
            })
}
    
    return(
        <DropdownMenu className="dropdown-navbar" right tag="ul">
            {isDone? history.push("/login"):null}
        {/* <DropdownItem divider tag="li" /> */}
                  {/* <NavLink tag="li"> */}
                    <DropdownItem className="nav-item" style={{"color": "#524A86","text-align": "center"}} onClick={handleLogout}>
                      {/* <Button></Button> */}
                      
                    Logout</DropdownItem>
                  {/* </NavLink> */}
                </DropdownMenu>
    );
}
